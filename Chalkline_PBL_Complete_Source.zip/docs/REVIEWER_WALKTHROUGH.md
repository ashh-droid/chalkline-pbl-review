# Chalkline — 5-minute technical walkthrough

The demo is a synthetic-data exercise. Use those words every time you discuss counts, grants or media.

## Minute 0–1 — Explain the finding

Open **Program review**, September 2025. The verdict is **Behind** because attendance is **60.6%**, the only overall indicator below the 75% target. Participation is 92.1% and evidence is 75.4%. Show the three bullet-chart rows, including their previous-month marks and target line. Explain why the attendance denominator is enrollment × 2 for Math + Science.

## Minute 1–2 — Take action from data

Select July on the **block matrix**, then September. The colour pattern shows changes without inventing new data. Select a red square and explain the three-month attendance trend and the weighted priority gap. On the **district strip plot**, click a dot to filter by district. Expand the full table briefly to show sorting/search/status filters.

## Minute 2–3 — Print the meeting pack

Open **Meeting pack**. Show a short, timed agenda, month-to-month changes, three named priority blocks, sample risk distribution, and proposed owner/date actions. Use **Print / PDF**; this has been checked to fit one A4 page in Chromium. All actions are **suggested** and must be confirmed by the programme team.

## Minute 3–4 — Defend the grant facts

Open **Grant reporting** → Grant AA → September. Explain why source totals are used only as reconciliation checks, not as inputs for KPI calculation. Hover/click citation `[F6]` and show the source fact in the right margin. Show finance by line, differences between rates and units, the period-end utilization gap, and synthetic evidence images. The app never quotes contradictory draft donor prose.

## Minute 4–4:30 — AI switched off

Toggle **AI off** (works without a key). Toggle **Optional AI** on the static site; the UI reports a deterministic fallback because there is no configured server endpoint. On a Node deployment, AI sees only the fact ledger and its output undergoes citation/numeric checks. A check passing does **not** prove every sentence is semantically entailed; an actual provider integration was not tested.

## Minute 4:30–5 — Live change

Show `src/config/thresholds.ts`. Change `ON_TRACK` from `75` to `80`, run `npm run build`, and reload. Explain that the threshold is referenced by `riskLevel`, the charts, priority ranking, and visible methods notes. Do **not** claim a threshold change will leave all prior test expectations unchanged: tests that intentionally assert the original boundaries may need to be updated alongside product requirements.

## Questions worth rehearsing

- Why not divide attendance by enrollment only? Because the source includes Math and Science as separate sessions.
- Why are PBL class/subject flags ignored in filters? They contradict recorded attendance in some rows; the assumption is visible in Data notes.
- Why use a deterministic generator first? Because non-AI rules must own all numbers and status labels, and the app has to work AI-off.
- How is finance handled? Both source and derived figures are preserved, and disagreements are flagged for human resolution.
- What would production require? Authentication, source provenance, audited imports, a transactional database, caching, observability and explicit human review of generative claims.
