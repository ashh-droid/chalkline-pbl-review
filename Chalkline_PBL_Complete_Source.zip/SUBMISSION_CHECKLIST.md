# Chalkline — submission checklist

- [ ] Verify the exact deadline: **72 hours after the email's sent timestamp**, not when it was opened.
- [ ] Run `npm test` (18 passing expected) and `npm run typecheck`.
- [ ] Create a GitHub repository (suggested: `chalkline-pbl-review`) and push the **full source**, data, images, tests, docs and README.
- [ ] Host the **contents of `site/`**. No key or build step is needed for the static demo.
- [ ] Test the actual public URL: month/district/block/class/subject filters, chart dots, block grid, trend panel, table, meeting pack, report citations, finance detail, images, export, print and AI-off fallback.
- [ ] Verify desktop and mobile. Check the browser console for errors and scroll to the evidence gallery to confirm lazy-loaded images work.
- [ ] Confirm no secret or API key appears in GitHub.
- [ ] Submit the repository URL, hosted demo URL and a short README/setup note via the official form.
- [ ] Practise the 5-minute walkthrough and threshold change before live review.

**Important:** All data and media are synthetic. Source totals and finance inconsistencies are flagged, not silently corrected. A public deployment has not yet been performed from this workspace; the demo URL must be verified before submission.
